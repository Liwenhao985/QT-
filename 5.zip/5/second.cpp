#include "second.h"
#include "widget.h"
#include "ui_second.h"
#include "third.h"
#include "forth.h"
#include <QMessageBox>
#include<QSqlError>
#include<QMessageBox>
#include<QSqlDatabase>
#include<QSqlQuery>
#include<QDebug>
#include<QSqlTableModel>
#include<QTextStream>
#include<QSqlRecord>
#include<QTableView>
#include<QMenu>
#include<QFile>
#include<QDate>
using namespace std;

second::second(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::second)
{
    qDebug()<<QSqlDatabase::drivers();

    QSqlDatabase db2;
    db2=QSqlDatabase::addDatabase("QMYSQL","con2");//取别名区分不同连接
    db2.setHostName("127.0.0.1");
    db2.setPort(3306);
    db2.setDatabaseName("test");
    db2.setUserName("root");
    db2.setPassword("123456");

    if(!db2.open()){
        QMessageBox::information(0,"提示","系统服务器崩溃");
    }

    ui->setupUi(this);
    model=new QSqlTableModel(this,db2);

    on_flushBt_clicked();
    ui->tableView->setModel(model);//model绑定tableView

    //设置页面标题
    this->setWindowTitle("SCUT学生管理系统");

    //实现搜索菜单
    ui->searchBt->setText("管理");
    QMenu *menu=new QMenu;
    QAction *action1=menu->addAction("显示全部学生信息");
    QAction *action2=menu->addAction("删除学生信息");
    QAction *action13=menu->addAction("编辑学生信息");
    QAction *action3=menu->addAction("查询学生信息");
    QAction *action4=menu->addAction("查询学生亲属信息");
    QAction *action5=menu->addAction("五天内过生日的学生");
    QAction *action12=menu->addAction("本月过生日的学生");
    ui->searchBt->setMenu(menu);
    connect(action1,&QAction::triggered,this,[=]{
        on_flushBt_clicked();
    });
    connect(action2,&QAction::triggered,this,[=]{
        on_deleteBt_clicked();
    });
    connect(action13,&QAction::triggered,this,[=]{
        on_editButton_clicked();
    });
    connect(action3,&QAction::triggered,this,[=]{
        on_searchBt_clicked();
    });
    connect(action4,&QAction::triggered,this,[=]{
        on_selectRelationshipsByName_clicked();
    });
    connect(action5,&QAction::triggered,this,[=]{
        on_selectBirethdayOnlyFiveDay_clicked();
    });
    connect(action12,&QAction::triggered,this,[=]{
        on_selectBirthdayThisMonByName_clicked();
    });

    //实现id排序菜单
    QMenu *menu2=new QMenu;
    QAction *action6=menu2->addAction("升序排序");
    QAction *action7=menu2->addAction("降序排序");
    ui->sortBt_1->setMenu(menu2);
    connect(action6,&QAction::triggered,this,[=]{
        on_raiseBt_clicked();
    });
    connect(action7,&QAction::triggered,this,[=]{
        on_lowerBt_clicked();
    });

    //实现出生日期排序菜单
    QMenu *menu3=new QMenu;
    QAction *action8=menu3->addAction("升序排序");
    QAction *action9=menu3->addAction("降序排序");
    ui->sortBt_2->setMenu(menu3);
    connect(action8,&QAction::triggered,this,[=]{
        on_raiseByBirthday_clicked();
    });
    connect(action9,&QAction::triggered,this,[=]{
        on_lowwerByBirthday_clicked();
    });

    //实现姓名排序菜单
    QMenu *menu4=new QMenu;
    QAction *action10=menu4->addAction("升序排序");
    QAction *action11=menu4->addAction("降序排序");
    ui->sortBt_3->setMenu(menu4);
    connect(action10,&QAction::triggered,this,[=]{
        on_raiseByName_clicked();
    });
    connect(action11,&QAction::triggered,this,[=]{
        on_lowwerByName_clicked();
    });

    ui->tableView->setEditTriggers(QAbstractItemView::NoEditTriggers);
}

//析构函数，释放ui
second::~second()
{
    delete ui;
}

//显示全部学生
void second::on_flushBt_clicked()
{
    QSqlQuery query;
    QString cmd=QString("create or replace view virtual_students as select id,name as '学生',gender as '性别',age as '年龄',birthday as '出生日期',phone as '手机号',email as '邮箱' "
                          "from students;");

    if(query.exec(cmd)){
        model->setTable("virtual_students");
        model->select();
    }
    else{
       QMessageBox::information(this,"警告","查询失败");
    }
}

//删除学生数据,要同步删除家长信息
void second::on_deleteBt_clicked()
{
    QSqlQuery query;
    QString studentName=ui->name->text();
    // 弹出询问框，让用户确认是否删除
    int reply = QMessageBox::question(this, tr("确认删除"), tr("你确定要删除该学生及其家长信息吗？"),
                                      QMessageBox::Yes | QMessageBox::No, QMessageBox::No);
    if (reply != QMessageBox::Yes) {
        return; // 用户选择不删除
    }

    //删除前记录该学生的id，方便删除家长信息
    query.exec(QString("select id from students where name='%1'").arg(studentName));
    int id;
    while(query.next()){
        QString data=query.value(0).toString();
        id=data.toInt();
    }

    QString cmd=QString("delete from students where name='%1'").arg(studentName);
    QString cmd2=QString("delete from stu_relations where stu_id='%1'").arg(id);

    if(query.exec(cmd)&&query.exec(cmd2)){
        QMessageBox::warning(this,tr("提示"),tr("删除成功"));
        on_flushBt_clicked();
    }
    else{
        QMessageBox::information(this,"警告","删除失败");
    }
}

//添加数据
void second::on_addBt_clicked()
{
    Third *third=new Third;
    this->hide();
    third->show();
}

//根据名字搜索
void second::on_searchBt_clicked()
{
    QSqlQuery query;
    QString name=ui->name->text();

    QString cmd=QString("create or replace view virtual_student as select id,name as '学生',gender as '性别',age as '年龄',birthday as '出生日期',phone as '手机号',email as '邮箱' from students where name='%1';").arg(name);

    if(query.exec(cmd)){
        model->setTable("virtual_student");
        model->select();
    }
    else{
        QMessageBox::information(this,"警告","查询失败");
    }
}

//按照id升序
void second::on_raiseBt_clicked()
{
    model->setSort(0,Qt::AscendingOrder);
    model->select();
}

//按照id降序
void second::on_lowerBt_clicked()
{
    model->setSort(0,Qt::DescendingOrder);
    model->select();
}

//退出登录
void second::on_closeBt_clicked()
{
    Widget *wid=new Widget;
    this->hide();
    wid->show();
    QMessageBox::information(0,"提示","退出成功");
}

//发送祝福语并保存到文件中（模拟邮箱）
void second::on_sendBt_clicked()
{
    QSqlQuery query;
    //刷新一下virtual_birthday_in_five_day_name，防止新增和删除的数据的影响
    QString cmd=QString("create or replace view virtual_birthday_in_five_day_name as SELECT name FROM students "
                          "WHERE DATE_FORMAT(birthday, '%m-%d') BETWEEN DATE_FORMAT(CURDATE(), '%m-%d') AND DATE_FORMAT(DATE_ADD(CURDATE(), INTERVAL 5 DAY), '%m-%d');");
    query.exec(cmd);
    query.exec("select name as 姓名 from virtual_birthday_in_five_day_name;");

    //把学生姓名记录下来
    QStringList resultList;
    while(query.next()){
        QString data=query.value(0).toString();
        resultList.append(data);
    }

    //获取当前登录的用户
    QString username;
    query.exec("select username from memory;");
    while(query.next()){
        username=query.value(0).toString();
    }

    QFile file("blessing.txt");//指定文件
    if(file.open(QIODevice::Append|QIODevice::Text)){
        QTextStream out(&file);
        for(const QString& name:resultList){

            //把生日前置0给去掉
            query.exec(QString("select birthday from students where name='%1'").arg(name));
            QString birthday;
            while(query.next()){
                birthday=query.value(0).toString();
            }
            QStringList list=birthday.split('-');
            if(list[1].toInt()<10){
                int data=list[1].toInt();
                list[1]=QString::number(data);
            }
            if(list[2].toInt()<10){
                int data=list[2].toInt();
                list[2]=QString::number(data);
            }

            out<<"亲爱的"<<name<<"同学：\n";
            out<<"    祝生日快乐，健康幸福。\n";
            out<<"                                            "<<username<<"\n";
            out<<"                                    "<<list[0]<<"年"<<list[1]<<"月"<<list[2]<<"日\n";
            out<<"--------------------------------------------------\n";
        }

        file.close();
        QMessageBox::information(0,"提示r","发送成功");
    }else{
        QMessageBox::warning(this,tr("提示"),tr("发送失败"));
    }
}

//查询学生亲属
void second::on_selectRelationshipsByName_clicked()
{
    QSqlQuery query;
    QString cmd=QString("create or replace view virtual_stu_relations_by_name as select stu_id as 学生id,stu_name as 学生,relation as 关系,name as 姓名,age as 年龄,work_unit as 工作单位 from stu_relations where stu_name='%1';").arg(ui->name->text());

    if(query.exec(cmd)){
        model->setTable("virtual_stu_relations_by_name");
        model->select();
    }
    else{
        QMessageBox::information(this,"警告","查询失败");
    }
}

//五天内过生日学生人数
void second::on_selectBirethdayOnlyFiveDay_clicked()
{
    QSqlQuery query;
    QString cmd=QString("create or replace view virtual_birthday_in_five_day as SELECT id,name as '学生',gender as '性别',age as '年龄',birthday as '出生日期',phone as '手机号',email as '邮箱' "
                          "FROM students WHERE DATE_FORMAT(birthday, '%m-%d') BETWEEN DATE_FORMAT(CURDATE(), '%m-%d') AND DATE_FORMAT(DATE_ADD(CURDATE(), INTERVAL 5 DAY), '%m-%d');");

    if(query.exec(cmd)){
        model->setTable("virtual_birthday_in_five_day");
        model->select();
    }
    else{
       QMessageBox::information(this,"警告","查询失败");
    }

    // 显示人数
    int rowCount = model->rowCount();
    QString info=QString("五天内过生日的学生共有%1位").arg(rowCount);
    QMessageBox::information(this,"五天内过生日人数",info);
}

//本月过生日学生人数
void second::on_selectBirthdayThisMonByName_clicked()
{
    QSqlQuery query;
    QString cmd=QString("create or replace view virtual_birthday_this_month as select id,name as '学生',gender as '性别',age as '年龄',birthday as '出生日期',phone as '手机号',email as '邮箱' "
                          "from students where month(birthday)=month(curdate());");

    if(query.exec(cmd)){
        model->setTable("virtual_birthday_this_month");
        model->select();
    }
    else{
        QMessageBox::information(this,"警告","查询失败");
    }

    // 显示人数
    int rowCount = model->rowCount();
    QString info=QString("本月生日的学生共有%1位").arg(rowCount);
    QMessageBox::information(this,"本月过生日人数",info);
}

//根据出生日期升序排序
void second::on_raiseByBirthday_clicked()
{
    QSqlQuery query;
    QString cmd=QString("create or replace view virtual_students_birthday as select id,name as '学生',gender as '性别',age as '年龄',birthday as '出生日期',phone as '手机号',email as '邮箱'"
                          " from students order by month(birthday),dayofmonth(birthday);");

    if(query.exec(cmd)){
        model->setTable("virtual_students_birthday");
        model->select();
    }
    else{
        QMessageBox::information(this,"警告","查询失败");
    }
}

//根据出生日期降序排序
void second::on_lowwerByBirthday_clicked()
{
    QSqlQuery query;
    QString cmd=QString("create or replace view virtual_students_birthday_desc as select id,name as '学生',gender as '性别',age as '年龄',birthday as '出生日期',phone as '手机号',email as '邮箱'"
                          " from students order by month(birthday),dayofmonth(birthday) desc;");

    if(query.exec(cmd)){
        model->setTable("virtual_students_birthday_desc");
        model->select();
    }
    else{
        QMessageBox::information(this,"警告","查询失败");
    }
}

//根据姓名升序排序
void second::on_raiseByName_clicked()
{
    QSqlQuery query;
    QString cmd=QString("create or replace view virtual_students_name as select id,name as '学生',gender as '性别',age as '年龄',birthday as '出生日期',phone as '手机号',email as '邮箱'"
                          " from students order by convert(name using gbk) collate gbk_chinese_ci;");

    if(query.exec(cmd)){
        model->setTable("virtual_students_name");
        model->select();
    }
    else{
       QMessageBox::information(this,"警告","查询失败");
    }
}

//根据姓名降序排序
void second::on_lowwerByName_clicked()
{
    QSqlQuery query;
    QString cmd=QString("create or replace view virtual_students_name_desc as select id,name as '学生',gender as '性别',age as '年龄',birthday as '出生日期',phone as '手机号',email as '邮箱'"
                          " from students order by convert(name using gbk) collate gbk_chinese_ci desc;");

    if(query.exec(cmd)){
        model->setTable("virtual_students_name_desc");
        model->select();
    }
    else{
        QMessageBox::information(this,"警告","查询失败");
    }
}

//修改学生信息
void second::on_editButton_clicked()
{
    QString name2=ui->name->text();
    if(name2.isEmpty()||name2.isNull()){
        QMessageBox::information(this,"警告","学生姓名不能为空");
        return;
    }
    QSqlQuery query;
    QString name=ui->name->text();
    QString cmd=QString("update memory2 set name='%1' where id=1").arg(name);
    if(!query.exec(cmd)){
        QMessageBox::information(this,"警告","记录失败");
    }
    forth *f=new forth;
    this->hide();
    f->show();
}

