#include "forth.h"
#include "ui_forth.h"
#include "second.h"
#include <QMessageBox>
#include<QSqlError>
#include<QMessageBox>
#include<QSqlDatabase>
#include<QSqlQuery>
#include<QDebug>
#include<QSqlTableModel>
#include<QTextStream>
#include<QSqlRecord>
#include<QTableView>
#include<QMenu>
#include<QFile>
#include<QDate>

QString stuName2;//记录添加的学生姓名

forth::forth(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::forth)
{
    QSqlDatabase db4;
    db4=QSqlDatabase::addDatabase("QMYSQL","con4");//创建数据库
    db4.setHostName("127.0.0.1");//连接本地主机
    db4.setPort(3306);
    db4.setDatabaseName("test");//调用已有的数据库
    db4.setUserName("root");//以root用户名访问
    db4.setPassword("123456");//连接密码
    if(!db4.open()){
        QMessageBox::information(0,"infor","连接数据库失败");
    }

    ui->setupUi(this);
    model4=new QSqlTableModel(this,db4);
    model4->setEditStrategy(QSqlTableModel::OnManualSubmit);
    model5=new QSqlTableModel(this,db4);
    model5->setEditStrategy(QSqlTableModel::OnManualSubmit);
    ui->stuTableView->setModel(model4);
    ui->stuRelationsTableView->setModel(model5);

    //设置页面标题
    this->setWindowTitle("学生管理");
    ui->stuTableView->setEditTriggers(QAbstractItemView::NoEditTriggers);
    showData();
}

forth::~forth()
{
    delete ui;
}

void forth::showData(){
    QSqlQuery query;
    QString create=QString("select name from memory2");
    query.exec(create);

    QString name;
    while(query.next()){
        name=query.value(0).toString();
    }
    stuName2=name;

    //展示学生信息
    QString create2=QString("create or replace view virtual_student as select id,name as '学生',gender as '性别',age as '年龄',birthday as '出生日期',phone as '手机号',email as '邮箱'"
                             " from students where name='%1'").arg(name);
    query.exec(create2);
    model4->setTable("virtual_student");
    model4->select();

    QString phone;
    QString gender;
    QString age;
    QString birthday;
    QString email;
    QString select2=QString("select * from virtual_student");
    query.exec(select2);
    while(query.next()){
        gender=query.value("性别").toString();
        age=query.value("年龄").toString();
        birthday=query.value("出生日期").toString();
        phone=query.value("手机号").toString();
        email=query.value("邮箱").toString();
    }
    ui->stuName1->setText(name);
    ui->stuAge->setText(age);
    ui->stuBirthday->setText(birthday);
    ui->stuEmail->setText(email);
    ui->stuGender->setText(gender);
    ui->stuPhone->setText(phone);

    //展示家长信息
    QString create3=QString("create or replace view virtual_stu_relations_add as select * from stu_relations where stu_name='%1'").arg(stuName2);
    query.exec(create3);
    model5->setTable("virtual_stu_relations_add");
    model5->select();
}

void forth::on_closeBt_clicked()
{
    second *sec=new second;
    this->hide();
    sec->show();
}

void forth::on_stuRelationsAddBt_clicked()
{
    QSqlQuery query3;

    QString stuRelationName=ui->stuRelationsName->text();
    QString relation=ui->relation->text();
    QString stuRelationAge=ui->stuRelationsAge->text();
    QString workUnit=ui->workUnit->text();

    if(stuName2.isEmpty()||stuRelationName.isEmpty()||stuRelationAge.isEmpty()||
        workUnit.isEmpty()||relation.isEmpty()){
        QMessageBox::information(this,"提示","学生亲属信息必须齐全");
        return;
    }

    //获取学生id
    QString select=QString("select id from students where name='%1'").arg(stuName2);
    int id;
    query3.exec(select);
    while(query3.next()){
        QString data=query3.value(0).toString();
        id=data.toInt();
    }

    QString cmd=QString("insert into stu_relations(stu_id,stu_name,relation,name,age,work_unit) values(%1,'%2','%3','%4',%5,'%6')")
                      .arg(id).arg(stuName2).arg(relation).arg(stuRelationName).arg(stuRelationAge).arg(workUnit);

    if(query3.exec(cmd)){
        //添加后及时展示已添加的数据
        QString select2=QString("create or replace view virtual_stu_relations_add as select * from stu_relations where stu_name='%1'").arg(stuName2);
        query3.exec(select2);
        model5->setTable("virtual_stu_relations_add");
        model5->select();
        ui->stuRelationsName->clear();
        ui->stuRelationsAge->clear();
        ui->workUnit->clear();
        ui->relation->clear();
    }
    else{
        QMessageBox::information(this,"警告","添加学生亲属信息失败");
    }
}


void forth::on_stuUpdateBt_clicked()
{
    QSqlQuery query;
    QString stuName1=ui->stuName1->text();
    QString stuGender=ui->stuGender->text();
    QString stuBirthday=ui->stuBirthday->text();
    QString stuPhone=ui->stuPhone->text();
    QString stuEmail=ui->stuEmail->text();
    QString stuAge=ui->stuAge->text();

    if(stuName1.isEmpty()||stuGender.isEmpty()||stuBirthday.isEmpty()||
        stuPhone.isEmpty()||stuEmail.isEmpty()||stuAge.isEmpty()){
        QMessageBox::information(this,"提示","学生信息必须齐全");
        return;
    }

    if(stuPhone.size()!=11){
        QMessageBox::information(this,"提示","手机号不合法");
        return;
    }

    if(stuAge.toInt()<12||stuAge.toInt()>100){
        QMessageBox::information(this,"提示","学生年龄不合规");
        return;
    }

    if(!("男"==stuGender||"女"==stuGender)){
        QMessageBox::information(this,"提示","学生性别不合规");
        return;
    }

    //获取学生id
    QString select=QString("select id from students where name='%1'").arg(stuName1);
    int id;
    query.exec(select);
    while(query.next()){
        QString data=query.value(0).toString();
        id=data.toInt();
    }

    QString cmd=QString("update students set name='%1',gender='%2',age=%3,birthday='%4',phone='%5',email='%6' where id='%7'")
                      .arg(stuName1).arg(stuGender).arg(stuAge).arg(stuBirthday).arg(stuPhone).arg(stuEmail).arg(id);
    if(query.exec(cmd)){
        //添加后及时展示已添加的数据
        QString select=QString("create or replace view virtual_student_add as select id,name as '学生',gender as '性别',age as '年龄',birthday as '出生日期',phone as '手机号',email as '邮箱'"
                                 " from students where name='%1'").arg(stuName1);
        query.exec(select);
        model4->setTable("virtual_student_add");
        model4->select();
    }
    else{
        QMessageBox::information(this,"警告","学生信息填写不合规，添加学生信息失败");
    }
}

