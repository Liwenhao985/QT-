#ifndef THIRD_H
#define THIRD_H

#include <QWidget>
#include <QSqlDatabase>
#include<QSqlTableModel>

namespace Ui {
class Third;
}

class Third : public QWidget
{
    Q_OBJECT

public:
    explicit Third(QWidget *parent = nullptr);
    ~Third();

private slots:
    void on_stuAddBt_clicked();

    void on_stuRelationsAddBt_clicked();

    void on_closeBt_clicked();

private:
    Ui::Third *ui;
    QSqlTableModel *model3;
    QSqlTableModel *model2;
};

#endif // THIRD_H
