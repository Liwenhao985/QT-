#ifndef FORTH_H
#define FORTH_H

#include <QWidget>
#include <QSqlDatabase>
#include<QSqlTableModel>

namespace Ui {
class forth;
}

class forth : public QWidget
{
    Q_OBJECT

public:
    explicit forth(QWidget *parent = nullptr);
    ~forth();

private slots:
    void on_closeBt_clicked();

    void on_stuRelationsAddBt_clicked();

    void on_stuUpdateBt_clicked();

    void showData();

private:
    Ui::forth *ui;
    QSqlTableModel *model4;
    QSqlTableModel *model5;
};

#endif // FORTH_H
