#include "widget.h"
#include "ui_widget.h"
#include "second.h"
#include <QMessageBox>
#include<QSqlError>
#include<QMessageBox>
#include<QSqlDatabase>
#include<QSqlQuery>
#include<QDebug>
#include<QSqlTableModel>

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    QSqlDatabase db;
    db=QSqlDatabase::addDatabase("QMYSQL");//创建数据库
    db.setHostName("127.0.0.1");//连接本地主机
    db.setPort(3306);//端口号
    db.setDatabaseName("test");//调用已有的数据库
    db.setUserName("root");//用户名
    db.setPassword("123456");//连接密码

    if(!db.open()){
        QMessageBox::information(0,"提示","连接失败");
    }

    ui->setupUi(this);
    model=new QSqlTableModel(this);//指定当前界面
    model->setTable("userinfo");
    model->select();

    this->setWindowTitle("SCUT登录系统");//设置页面标题

    timer=new QTimer;
    pictureid=2;//初始化图片编号
    QImage img;//创建图像对象
    img.load("E:\\1.jpg");//上传图片
    ui->picturelabel->setPixmap(QPixmap::fromImage(img));//label上展示图片

    //定时器时间到，发出timeout信号，对信号进行接收和处理
    connect(timer,&QTimer::timeout,this, &Widget::timeoutSlot);
    timer->start(TIMEOUT);//按下开始则以每TIMEOUT秒进行播放
}

Widget::~Widget()
{
    delete ui;
}

//登录功能
void Widget::on_loginBt_clicked()
{
    QString username=ui->textUserName->text();
    QString password=ui->txtPassWord->text();
    if(username.isEmpty()||password.isEmpty()){
        QMessageBox::information(this,"注册提示","用户名和密码不能为空");
        return;
    }

    QSqlTableModel *model2=new QSqlTableModel;
    model2->setTable("userinfo");//指定查询的表
    model2->setFilter(QString("username='%1' and password='%2'").arg(username).arg(password));//指定查询的数据
    model2->select();//查询

    //查询是否有此数据（以查询的行数为依据）
    int row=model2->rowCount();
    if(row>0)
    {
        QMessageBox::information(this,"登录提示","登录成功");
        second *sec=new second;
        this->hide();
        sec->show();
    }
    else
    {
        QMessageBox::information(this,"登录提示","用户名或密码错误");
    }

    //在memory中记录登录的用户,方面后面使用
    QSqlQuery query;
    QString sql=QString("update memory set username='%1' where id =1").arg(username);
    query.exec(sql);

    delete model2;
}

//注册功能
void Widget::on_registerBt_clicked()
{
    QSqlQuery query;
    QString username=ui->textUserName->text();
    QString password=ui->txtPassWord->text();
    if(username.isEmpty()||password.isEmpty()){
        QMessageBox::information(this,"注册提示","用户名和密码不能为空");
        return;
    }

    //已存在的用户不能再次注册
    QString select= QString("select * from userinfo where username='%1'").arg(username);
    query.exec(select);
    if(query.next()){
        QMessageBox::information(this,"注册提示","用户已存在");
        return;
    }

    //插入注册的用户名和密码
    QString cmd=QString("insert into userinfo(username,password) values('%1','%2')").arg(username).arg(password);//插入数据库
    if(query.exec(cmd))
    {
        QMessageBox::information(this,"注册提示","注册成功");
    }
    else
    {
        QMessageBox::information(this,"注册提示","注册失败");
    }
}

//登录页面的背景图滚动
void Widget::timeoutSlot()
{
    //得到不同图片路径
    QString path("E:\\");
    path +=QString::number(pictureid);
    path +=".jpg";

    //显示图片
    QImage img;
    img.load(path);
    ui->picturelabel->setPixmap(QPixmap::fromImage(img));

    //让图片循环播放
    pictureid++;
    if (7== pictureid)
        pictureid =1;
}

