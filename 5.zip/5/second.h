#ifndef SECOND_H
#define SECOND_H

#include <QWidget>
#include <QSqlDatabase>
#include<QSqlTableModel>

namespace Ui {
class second;
}

class second : public QWidget
{
    Q_OBJECT

public:
    explicit second(QWidget *parent = nullptr);
    ~second();

private slots:


    void on_flushBt_clicked();

    void on_deleteBt_clicked();

    void on_addBt_clicked();

    void on_lineEdit_cursorPositionChanged(int arg1, int arg2);

    void on_searchBt_clicked();

    void on_raiseBt_clicked();

    void on_lowerBt_clicked();

    void on_closeBt_clicked();

    void on_sendBt_clicked();


    void on_selectRelationshipsByName_clicked();

    void on_selectBirethdayOnlyFiveDay_clicked();

    void on_selectBirthdayThisMonByName_clicked();

    void on_raiseByBirthday_clicked();

    void on_lowwerByBirthday_clicked();

    void on_raiseByName_clicked();

    void on_lowwerByName_clicked();

    void on_editButton_clicked();

private:
    Ui::second *ui;
    QSqlTableModel *model;
};

#endif // SECOND_H
