#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QSqlDatabase>
#include<QSqlTableModel>
#include<QPainter>
#include<QTimer>  //包含头文件

#define TIMEOUT  3*1000//定义一个停止时长的函数

QT_BEGIN_NAMESPACE
namespace Ui {
class Widget;
}
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

private slots:
    void on_loginBt_clicked();

    void on_registerBt_clicked();

    void timeoutSlot();//注意，槽函数必须要写在Slot下面

private:
    Ui::Widget *ui;
    QSqlTableModel *model;
    QTimer *timer;
    int pictureid;//定义一个图片编号
    int pictureid2;//定义一个图片编号
};
#endif // WIDGET_H
