#ifndef QTCONNECT_H
#define QTCONNECT_H

#include<QMessageBox>
#include<QSqlDatabase>
#include<QSqlQuery>
#include<QDebug>

static bool createConnection()
{
    qDebug()<<QSqlDatabase::drivers();

    QSqlDatabase db=QSqlDatabase::addDatabase("QMYSQL");
    db.setHostName("127.0.0.1");//连接本地主机
    db.setPort(3306);
    db.setDatabaseName("test");
    db.setUserName("root");
    db.setPassword("123456");



    if(db.open()){
        QMessageBox::information(0,"infor","link success");
    }
    else{
        QMessageBox::information(0,"infor","link failed");
    }

    //下面创建表
    QSqlQuery query(db);

    //使数据库支持中文
    query.exec("SET NAMES 'Latin1'");
    //创建course表
    query.exec("create table course(id int primary key,"
               "name varchar(10),teacher varchar(20))");
    query.exec("insert into course values(0,'数学','张老师')");
    query.exec("insert into course values(1,'语文','李老师')");
    query.exec("insert into course values(2,'英语','王老师')");

    if(query.isActive())
    {
        qDebug()<<"Table created success";
    }
    else
    {
        qDebug()<<"Table created failed";
    }
    return true;
}

#endif // QTCONNECT_H
